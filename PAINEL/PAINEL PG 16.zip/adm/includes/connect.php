<?php
		$link = mysqli_connect("localhost", "painel", "2KdJir653JKXnGa2");
		mysqli_select_db($link, "painel");
		mysqli_query($link, "SET CHARACTER SET utf8");
		?>
		