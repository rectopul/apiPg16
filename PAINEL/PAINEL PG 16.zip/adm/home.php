<?php
		include "includes/header.php";
		?>
		<table class="table table-striped">
		<tr>
		<th class="not">Table</th>

		</tr>
		
				<tr>
					<td><a href="users.php">Users</a></td>
			
				
				</tr>
				<tr>
						<td><a href="agents.php">Agents</a></td>
				
				</tr>
				
				
				</table>
			<?php include "includes/footer.php";?>
			