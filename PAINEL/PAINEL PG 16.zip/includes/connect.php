<?php
		$link = mysqli_connect("127.0.0.1", "root", "777slots777", "apipg16", 3307);
		mysqli_query($link, "SET CHARACTER SET utf8");
		?>
		