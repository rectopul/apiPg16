<?php
	setcookie("admin_id","");
	setcookie("admin_pass","");
	setcookie("auth","");
	header("location:"."index.php");
?>
